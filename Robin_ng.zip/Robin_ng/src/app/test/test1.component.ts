import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test1',
  template: `
    <p>
      test1 works!</p>
      <h1>it's ng cli based...</h1>
      <button class="btn btn-info">Click Here...</button>
    
  `,
  styles: [
`p{
  color: green;
  font-size: 3em;
},
#myId{
  
}
`

  ]
})
export class Test1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
