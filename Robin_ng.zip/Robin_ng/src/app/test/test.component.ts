import { Component } from "@angular/core";


@Component({
    selector: 'app-test',
    template:`<h1>This is a test component</h1>
                <p>Uderstanding component...</p>
                <button class="btn btn-primary">Click Here...</button>
                `
})

export class TestComponent{}
