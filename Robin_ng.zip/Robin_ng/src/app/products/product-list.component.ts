import { Component, OnInit } from '@angular/core';
import {IProducts} from './products';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit
 {
   pageTitle : String = 'Product-Application'
   showImage: boolean=false
   listFilter: String=''

   products

  constructor(private _productService:ProductService) { }

  ngOnInit() {
    console.log(`Life cycle hook method ngOnInt called`)
    //this.products=this._productService.getProducts()
    this._productService.getProducts().subscribe((products)=>this.products=products)
  }

  toggleImage(): void{
    this.showImage = !this.showImage
  }

  onRatingClicked(message:string):void{
    console.log(message)
    this.pageTitle ='Product-Application-Rating:'+ message
  }

}
